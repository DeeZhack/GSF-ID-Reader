package com.example.gsfidreader;

import android.app.Activity;
import android.os.Bundle;
import android.database.Cursor;
import android.net.Uri;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView result;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("GSF ID Reader");
        title.setTextSize(24);
        layout.addView(title);

        result = new TextView(this);
        result.setText("Tekan GET GSF ID untuk membaca ID.");
        result.setTextSize(17);
        result.setPadding(0, 30, 0, 30);
        result.setTextIsSelectable(true);
        layout.addView(result);

        Button read = new Button(this);
        read.setText("GET GSF ID");
        read.setOnClickListener(v -> readGsfId());
        layout.addView(read);

        Button copy = new Button(this);
        copy.setText("SALIN ID");
        copy.setOnClickListener(v -> {
            String value = result.getText().toString().trim();
            if (value.matches("[0-9a-fA-F]{1,16}")) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("GSF ID", value));
                Toast.makeText(this, "GSF ID disalin", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Belum ada GSF ID yang valid", Toast.LENGTH_SHORT).show();
            }
        });
        layout.addView(copy);

        TextView note = new TextView(this);
        note.setText("\nAplikasi hanya membaca GSF ID. Tidak mengubah sistem dan tidak membutuhkan root. Keberhasilan membaca bergantung pada izin ROM.");
        note.setTextSize(13);
        note.setPadding(0, 24, 0, 0);
        layout.addView(note);

        setContentView(layout);
    }

    private void readGsfId() {
        Uri uri = Uri.parse("content://com.google.android.gsf.gservices");
        String[] projection = new String[] {"name", "value"};
        String selection = "name=?";
        String[] selectionArgs = new String[] {"android_id"};

        try (Cursor cursor = getContentResolver().query(
                uri, projection, selection, selectionArgs, null)) {

            if (cursor == null) {
                result.setText("Gagal: provider GSF tidak mengembalikan cursor.");
                return;
            }

            int valueIndex = cursor.getColumnIndex("value");
            if (valueIndex < 0) {
                result.setText("Gagal: kolom value tidak tersedia. Kolom: " +
                        java.util.Arrays.toString(cursor.getColumnNames()));
                return;
            }

            if (!cursor.moveToFirst()) {
                result.setText("GSF ID tidak ditemukan. Provider tidak mengembalikan baris android_id.");
                return;
            }

            String raw = cursor.getString(valueIndex);
            if (raw == null || raw.trim().isEmpty()) {
                result.setText("GSF ID kosong.");
                return;
            }

            // GServices menyimpan android_id sebagai angka desimal; registrasi biasanya memakai hex.
            long decimal = Long.parseLong(raw.trim());
            String hex = Long.toHexString(decimal);
            result.setText(hex);

        } catch (SecurityException e) {
            result.setText("Permission Denial: ROM menolak READ_GSERVICES untuk aplikasi ini.");
        } catch (NumberFormatException e) {
            result.setText("Nilai GSF bukan angka desimal: " + e.getMessage());
        } catch (Exception e) {
            result.setText("Error: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
