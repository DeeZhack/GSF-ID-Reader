package com.example.gsfidreader;

import android.app.Activity;
import android.os.Bundle;
import android.database.Cursor;
import android.net.Uri;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView result;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("GSF ID Reader");
        title.setTextSize(24);
        title.setPadding(0, 0, 0, 24);
        layout.addView(title);

        result = new TextView(this);
        result.setText("Tekan tombol untuk membaca GSF ID.");
        result.setTextSize(17);
        result.setTextIsSelectable(true);
        result.setPadding(0, 16, 0, 24);
        layout.addView(result);

        Button read = new Button(this);
        read.setText("GET GSF ID");
        read.setOnClickListener(v -> readGsfId());
        layout.addView(read);

        Button copy = new Button(this);
        copy.setText("SALIN ID");
        copy.setOnClickListener(v -> {
            String value = result.getText().toString();
            if (value.matches("[0-9a-fA-F]{1,16}")) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("GSF ID", value));
                Toast.makeText(this, "GSF ID disalin", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Belum ada GSF ID untuk disalin", Toast.LENGTH_SHORT).show();
            }
        });
        layout.addView(copy);

        TextView note = new TextView(this);
        note.setText("\nAplikasi ini hanya membaca ID dari Google Services Framework. Tidak mengubah sistem, tidak membutuhkan root, dan tidak menjamin status Play Protect Certified.");
        note.setTextSize(13);
        note.setPadding(0, 24, 0, 0);
        layout.addView(note);

        setContentView(layout);
    }

    private void readGsfId() {
        try {
            Uri uri = Uri.parse("content://com.google.android.gsf.gservices");
            String[] projection = new String[] {"value"};
            String[] args = new String[] {"android_id"};

            try (Cursor cursor = getContentResolver().query(
                    uri, projection, "name=?", args, null)) {
                if (cursor == null) {
                    result.setText("Gagal: provider tidak mengembalikan data.");
                    return;
                }
                if (!cursor.moveToFirst()) {
                    result.setText("GSF ID tidak ditemukan pada provider.");
                    return;
                }

                String raw = cursor.getString(0);
                if (raw == null || raw.isEmpty()) {
                    result.setText("GSF ID kosong.");
                    return;
                }

                try {
                    long decimal = Long.parseLong(raw);
                    String hex = Long.toHexString(decimal);
                    result.setText(hex);
                } catch (NumberFormatException e) {
                    result.setText("Nilai provider tidak dapat dikonversi: " + raw);
                }
            }
        } catch (SecurityException e) {
            result.setText("Permission Denial: ROM tidak mengizinkan aplikasi membaca GSF. Root tidak otomatis diperlukan; masalahnya adalah kebijakan permission.");
        } catch (Exception e) {
            result.setText("Gagal membaca GSF: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
